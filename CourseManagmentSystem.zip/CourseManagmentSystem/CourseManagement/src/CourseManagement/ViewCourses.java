package CourseManagement;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class ViewCourses extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	JLabel l1,l2,l3;
    JTable t1;
    JButton b1,b2,b3;
    JTextField t2;
    String x[] = {"Course Name","Course ID","Branch","Instructor"};
    String y[][] = new String[20][10];
    int i=0, j=0;
    ViewCourses(){
        super("Course Details");
        setSize(1200,600);
        setLocation(150,150);
        setLayout(null);
        try{
            Conn c1  = new Conn();
            String s1 = "select * from course";
            ResultSet rs  = c1.s.executeQuery(s1);
            while(rs.next()){
                y[i][j++]=rs.getString("coursename");
                y[i][j++]=rs.getString("courseid");
                y[i][j++]=rs.getString("Branch");
                y[i][j++]=rs.getString("Instructor");
                i++;
                j=0;
            }
            t1 = new JTable(y,x);
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
        JScrollPane sp = new JScrollPane(t1);
        sp.setBounds(20,20,1200,330);
        add(sp);
        
        getContentPane().setBackground(Color.WHITE);
        

    }
    public void actionPerformed(ActionEvent ae){
        
        Conn c1 = new Conn();
    
        if(ae.getSource() == b1){
            try{
                String a = t2.getText();
                String q = "delete from student where rollno = '"+a+"'";
                c1.s.executeUpdate(q);
                this.setVisible(false);
                new StudentDetails().setVisible(true);
            }catch(Exception e){}
    
        }else if(ae.getSource() == b2){
            new AddStudent().f.setVisible(true);
            this.setVisible(false);
        }
    }
    public static void main(String[] args){
        new ViewCourses().setVisible(true);
    }   
}
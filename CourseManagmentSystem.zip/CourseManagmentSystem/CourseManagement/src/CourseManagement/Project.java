package CourseManagement;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Project extends JFrame implements ActionListener{
	
	private static final long serialVersionUID = 1L;


	Project(){
        super("Course Management System");
        
        setLocation(-5, 0);
        setSize(1800,800);
        
        ImageIcon ic =  new ImageIcon(getClass().getResource("/myicons/mainscreen.png"));
        Image i3 = ic.getImage().getScaledInstance(1900, 950,Image.SCALE_DEFAULT);
        ImageIcon icc3 = new ImageIcon(i3);
        JLabel l1 = new JLabel(icc3);
        
        add(l1);
        
        JMenuBar mb  = new JMenuBar();
        
        JMenu master = new JMenu("Master");
        JMenuItem m1 = new JMenuItem("New Faculty");
        JMenuItem m2 = new JMenuItem("New Student Admission");
        master.setForeground(Color.BLUE);
              
        m1.setFont(new Font("monospaced",Font.BOLD,16));
        ImageIcon icon1 = new ImageIcon(getClass().getResource("/myicons/icon2.png"));
        Image image1 = icon1.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        m1.setIcon(new ImageIcon(image1));
        m1.setBackground(Color.WHITE);
        
        m2.setFont(new Font("monospaced",Font.BOLD,16));
        ImageIcon icon2 = new ImageIcon(getClass().getResource("/myicons/icon1.png"));
        Image image2 = icon2.getImage().getScaledInstance(20, 20,Image.SCALE_DEFAULT);
        m2.setIcon(new ImageIcon(image2));
        m2.setBackground(Color.WHITE);
            
        m1.addActionListener(this);
        m2.addActionListener(this);
        
        
        JMenu course = new JMenu("Course");
        JMenuItem co1= new JMenuItem("Add New Course");
        JMenuItem co2 = new JMenuItem("View Courses");
        course.setForeground(Color.BLUE);
        
        co1.setFont(new Font("monospaced", Font.BOLD,16));
        ImageIcon icon10 = new ImageIcon(getClass().getResource("/myicons/icon17.png"));
        Image image10 = icon10.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        co1.setIcon(new ImageIcon(image10));
        co1.setBackground(Color.WHITE);
        
        co2.setFont(new Font("monospaced", Font.BOLD,16));
        ImageIcon icon11 = new ImageIcon(getClass().getResource("/myicons/icon4.png"));
        Image image11 = icon11.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        co2.setIcon(new ImageIcon(image11));
        co2.setBackground(Color.WHITE);
        
        co1.addActionListener(this);
        co2.addActionListener(this);
        
        
        JMenu user = new JMenu("Details");
        JMenuItem u1 = new JMenuItem("Student Details");
        JMenuItem u2 = new JMenuItem("Teacher Details");
        user.setForeground(Color.BLUE);
        
        u1.setFont(new Font("monospaced",Font.BOLD,16));
        ImageIcon icon4 = new ImageIcon(getClass().getResource("/myicons/icon3.png"));
        Image image4 = icon4.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        u1.setIcon(new ImageIcon(image4));
        u1.setBackground(Color.WHITE);
        
        u2.setFont(new Font("monospaced",Font.BOLD,16));
        ImageIcon icon5 = new ImageIcon(getClass().getResource("/myicons/icon4.png"));
        Image image5 = icon5.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        u2.setIcon(new ImageIcon(image5));
        u2.setBackground(Color.WHITE);
        
        u1.addActionListener(this);
        u2.addActionListener(this);
        
        
        JMenu exam = new JMenu("Examination");
        JMenuItem c1 = new JMenuItem("Examination Details");
        JMenuItem c2 = new JMenuItem("Enter Marks");
        exam.setForeground(Color.BLUE);
        
        c1.setFont(new Font("monospaced",Font.BOLD,16));
        ImageIcon icon30 = new ImageIcon(getClass().getResource("/myicons/icon16.png"));
        Image image31 = icon30.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        c1.setIcon(new ImageIcon(image31));
        c1.setBackground(Color.WHITE);
        exam.add(c1);
        
        c2.setFont(new Font("monospaced",Font.BOLD,16));
        ImageIcon icon32 = new ImageIcon(getClass().getResource("/myicons/icon17.png"));
        Image image33 = icon32.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        c2.setIcon(new ImageIcon(image33));
        c2.setBackground(Color.WHITE);
        exam.add(c2);

        c1.addActionListener(this);
        c2.addActionListener(this);

        
        JMenu exit = new JMenu("Exit");
        JMenuItem ex = new JMenuItem("Exit");
        exit.setForeground(Color.RED);
        

        ex.setFont(new Font("monospaced",Font.BOLD,16));
        ImageIcon icon111 = new ImageIcon(getClass().getResource("/myicons/icon12.png"));
        Image image111 = icon111.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        ex.setIcon(new ImageIcon(image111));
        ex.setMnemonic('Z');
        ex.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, ActionEvent.CTRL_MASK));
        ex.setBackground(Color.WHITE);
        
        ex.addActionListener(this);
        
        master.add(m1);
        master.add(m2);
        course.add(co1);
        course.add(co2);
        user.add(u1);
        user.add(u2);
        
        exit.add(ex);
         
        mb.add(master);
        mb.add(user);
        mb.add(course);
        mb.add(exam);
        mb.add(exit);
        
        setJMenuBar(mb);  
        
        setFont(new Font("Senserif",Font.BOLD,16));
        setLayout(new FlowLayout());
        setVisible(false);
    }
    public void actionPerformed(ActionEvent ae){
        String msg = ae.getActionCommand();
        if(msg.equals("New Student Admission")){
            new AddStudent().f.setVisible(true); 
        }
        else if(msg.equals("New Faculty")){
            new AddTeacher().f.setVisible(true);  
        }
        else if(msg.equals("Student Details")){
            new StudentDetails().setVisible(true);  
        }
        else if(msg.equals("Teacher Details")){
            new TeacherDetails().setVisible(true);
        }
        else if(msg.equals("Add New Course")){
            new AddCourse().f.setVisible(true);
        }
        else if(msg.equals("View Courses"))
        {
            new ViewCourses().setVisible(true);
        }
    	else if(msg.equals("Examination Details")){
            new ExaminationDetails().setVisible(true);
        }
    	else if(msg.equals("Enter Marks")){
            new EnterMarks().setVisible(true);
        }
    	else if(msg.equals("Exit"))
    	{
            System.exit(0);
        }
    }
    
    public static void main(String[] args){
        new Project().setVisible(true);
    }
}